"use client"

import { useState, useEffect } from "react"
import { DataGrid } from "@/components/data-grid"
import { ExportControls } from "@/components/export-controls"
import { SetSelector } from "@/components/set-selector"
import { StatsDashboard } from "@/components/stats-dashboard"
import { useCardData } from "@/hooks/use-card-data"
import { loadCardData, getMaxCardNumber, getSetTypes, type SetName } from "@/lib/card-sets"

export default function Home() {
  const [currentSet, setCurrentSet] = useState<SetName>("Black Bolt")
  const [maxCardNumber, setMaxCardNumber] = useState(999)
  const [isLoading, setIsLoading] = useState(true)
  const [availableTypes, setAvailableTypes] = useState<string[]>([])
  const { setCurrentSet: updateStoreSet } = useCardData()

  useEffect(() => {
    loadCardData().then(() => {
      setMaxCardNumber(getMaxCardNumber(currentSet))
      setAvailableTypes(getSetTypes(currentSet))
      setIsLoading(false)
    })
  }, [currentSet])

  const handleSetChange = (newSet: SetName) => {
    setCurrentSet(newSet)
    updateStoreSet(newSet)
    setMaxCardNumber(getMaxCardNumber(newSet))
    setAvailableTypes(getSetTypes(newSet))
  }

  if (isLoading) {
    return (
      <main className="h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-lg font-semibold">Loading card data...</div>
          <div className="text-sm text-muted-foreground mt-2">Please wait</div>
        </div>
      </main>
    )
  }

  return (
    <main className="h-screen flex flex-col">
      <header className="border-b border-border bg-card px-4 py-2.5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">PokeData - Bulk Uploader</h1>
            <p className="text-xs text-muted-foreground">Keyboard-first Pokémon card data entry</p>
          </div>
          <ExportControls currentSet={currentSet} />
        </div>
      </header>
      <div className="border-b border-border bg-muted/30 px-4 py-2">
        <SetSelector currentSet={currentSet} onSetChange={handleSetChange} />
      </div>
      <StatsDashboard totalCardsInSet={maxCardNumber} availableTypes={availableTypes} currentSet={currentSet} />
      <div className="flex-1 overflow-hidden">
        <DataGrid currentSet={currentSet} maxCardNumber={maxCardNumber} />
      </div>
    </main>
  )
}
