"use client"

import { useCardData } from "@/hooks/use-card-data"
import { Card } from "@/components/ui/card"
import { TrendingUp, Package, Target, Sparkles } from "lucide-react"
import { useEffect, useState } from "react"
import { getCardInfo, type SetName } from "@/lib/card-sets"

interface StatsDashboardProps {
  totalCardsInSet: number
  availableTypes: string[]
  currentSet: SetName
}

export function StatsDashboard({ totalCardsInSet, availableTypes, currentSet }: StatsDashboardProps) {
  const { getAllEntries, getCardNumbers } = useCardData()
  const [prevStats, setPrevStats] = useState({ uniqueCards: 0, totalQuantity: 0 })

  const allEntries = getAllEntries()
  const uniqueCards = getCardNumbers().length
  const totalQuantity = allEntries.reduce((sum, entry) => sum + entry.quantity, 0)
  const completionPercentage = totalCardsInSet > 0 ? Math.round((uniqueCards / totalCardsInSet) * 100) : 0

  useEffect(() => {
    setPrevStats({ uniqueCards, totalQuantity })
  }, [uniqueCards, totalQuantity])

  const getCompletionColor = (percentage: number) => {
    if (percentage >= 80) return "text-emerald-600 dark:text-emerald-400"
    if (percentage >= 50) return "text-amber-600 dark:text-amber-400"
    if (percentage >= 25) return "text-orange-600 dark:text-orange-400"
    return "text-rose-600 dark:text-rose-400"
  }

  const getCompletionBg = (percentage: number) => {
    if (percentage >= 80) return "bg-emerald-500/10 border-emerald-500/20"
    if (percentage >= 50) return "bg-amber-500/10 border-amber-500/20"
    if (percentage >= 25) return "bg-orange-500/10 border-orange-500/20"
    return "bg-rose-500/10 border-rose-500/20"
  }

  const typeBreakdown = availableTypes.reduce(
    (acc, type) => {
      acc[type] = allEntries.filter((e) => e.type === type).reduce((sum, e) => sum + e.quantity, 0)
      return acc
    },
    {} as Record<string, number>,
  )

  const topTypes = Object.entries(typeBreakdown)
    .filter(([, count]) => count > 0)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)

  const maxTypeCount = Math.max(...Object.values(typeBreakdown), 1)

  const pokemonFrequency = allEntries.reduce(
    (acc, entry) => {
      if (!acc[entry.cardNumber]) {
        acc[entry.cardNumber] = 0
      }
      acc[entry.cardNumber] += entry.quantity
      return acc
    },
    {} as Record<number, number>,
  )

  const topPokemon = Object.entries(pokemonFrequency)
    .map(([cardNum, totalQty]) => {
      const cardInfo = getCardInfo(currentSet, Number(cardNum))
      return {
        cardNumber: Number(cardNum),
        name: cardInfo?.name || `Card ${cardNum}`,
        totalQuantity: totalQty,
      }
    })
    .sort((a, b) => b.totalQuantity - a.totalQuantity)
    .slice(0, 5)

  const maxPokemonCount = Math.max(...topPokemon.map((p) => p.totalQuantity), 1)

  return (
    <div className="px-4 py-2 bg-gradient-to-br from-background via-muted/20 to-background border-b border-border">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-2">
        {/* Total Cards */}
        <Card className="p-2 bg-gradient-to-br from-card to-card/50 border-border/50 shadow-sm hover:shadow-md transition-all duration-300">
          <div className="flex items-center justify-between mb-1">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Total Cards</div>
            <Package className="h-4 w-4 text-muted-foreground/50" />
          </div>
          <div className="text-3xl font-bold bg-gradient-to-br from-foreground to-foreground/70 bg-clip-text text-transparent">
            {totalCardsInSet}
          </div>
        </Card>

        {/* Cards Entered with Progress */}
        <Card
          className={`p-2 bg-gradient-to-br from-card to-card/50 border shadow-sm hover:shadow-md transition-all duration-300 ${getCompletionBg(completionPercentage)}`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Progress</div>
            <Target className={`h-4 w-4 ${getCompletionColor(completionPercentage)}`} />
          </div>
          <div className={`text-3xl font-bold ${getCompletionColor(completionPercentage)}`}>{uniqueCards}</div>
          <div className="mt-1 space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">{completionPercentage}% complete</span>
              {completionPercentage >= 100 && <Sparkles className="h-3 w-3 text-amber-500 animate-pulse" />}
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ease-out ${
                  completionPercentage >= 80
                    ? "bg-gradient-to-r from-emerald-500 to-emerald-600"
                    : completionPercentage >= 50
                      ? "bg-gradient-to-r from-amber-500 to-amber-600"
                      : completionPercentage >= 25
                        ? "bg-gradient-to-r from-orange-500 to-orange-600"
                        : "bg-gradient-to-r from-rose-500 to-rose-600"
                }`}
                style={{ width: `${Math.min(completionPercentage, 100)}%` }}
              />
            </div>
          </div>
        </Card>

        {/* Total Quantity */}
        <Card className="p-2 bg-gradient-to-br from-card to-card/50 border-border/50 shadow-sm hover:shadow-md transition-all duration-300">
          <div className="flex items-center justify-between mb-1">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Total Qty</div>
            <TrendingUp className="h-4 w-4 text-blue-500/70" />
          </div>
          <div className="text-3xl font-bold bg-gradient-to-br from-blue-600 to-blue-500 dark:from-blue-400 dark:to-blue-300 bg-clip-text text-transparent">
            {totalQuantity}
          </div>
          {totalQuantity > prevStats.totalQuantity && (
            <div className="text-xs text-emerald-600 dark:text-emerald-400 mt-1 animate-pulse">
              +{totalQuantity - prevStats.totalQuantity}
            </div>
          )}
        </Card>

        {/* Unique Entries */}
        <Card className="p-2 bg-gradient-to-br from-card to-card/50 border-border/50 shadow-sm hover:shadow-md transition-all duration-300">
          <div className="flex items-center justify-between mb-1">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Entries</div>
            <Sparkles className="h-4 w-4 text-purple-500/70" />
          </div>
          <div className="text-3xl font-bold bg-gradient-to-br from-purple-600 to-purple-500 dark:from-purple-400 dark:to-purple-300 bg-clip-text text-transparent">
            {allEntries.length}
          </div>
        </Card>
      </div>

      {topTypes.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          {/* Top Types Cards */}
          <div className="grid grid-cols-3 gap-2">
            {topTypes.map(([type, count], index) => (
              <Card
                key={type}
                className="p-2 bg-gradient-to-br from-card to-card/50 border-border/50 shadow-sm hover:shadow-md transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="text-xs font-medium text-muted-foreground truncate">{type}</div>
                  <div
                    className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                      index === 0
                        ? "bg-amber-500/20 text-amber-700 dark:text-amber-300"
                        : index === 1
                          ? "bg-slate-500/20 text-slate-700 dark:text-slate-300"
                          : "bg-orange-500/20 text-orange-700 dark:text-orange-300"
                    }`}
                  >
                    #{index + 1}
                  </div>
                </div>
                <div className="text-2xl font-bold">{count}</div>
              </Card>
            ))}
          </div>

          <Card className="p-2 bg-gradient-to-br from-card to-card/50 border-border/50 shadow-sm">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              Rarity Distribution
            </div>
            <div className="space-y-1.5">
              {Object.entries(typeBreakdown)
                .filter(([, count]) => count > 0)
                .sort(([, a], [, b]) => b - a)
                .slice(0, 5)
                .map(([type, count]) => (
                  <div key={type} className="flex items-center gap-2">
                    <div className="text-xs font-medium text-muted-foreground w-20 truncate">{type}</div>
                    <div className="flex-1 h-4 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-500"
                        style={{ width: `${(count / maxTypeCount) * 100}%` }}
                      />
                    </div>
                    <div className="text-xs font-bold text-foreground w-8 text-right">{count}</div>
                  </div>
                ))}
            </div>
          </Card>

          <Card className="p-2 bg-gradient-to-br from-card to-card/50 border-border/50 shadow-sm">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Top Pokémon</div>
            <div className="space-y-1.5">
              {topPokemon.map((pokemon) => (
                <div key={pokemon.cardNumber} className="flex items-center gap-2">
                  <div className="text-xs font-medium text-muted-foreground w-20 truncate" title={pokemon.name}>
                    {pokemon.name}
                  </div>
                  <div className="flex-1 h-4 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-500"
                      style={{ width: `${(pokemon.totalQuantity / maxPokemonCount) * 100}%` }}
                    />
                  </div>
                  <div className="text-xs font-bold text-foreground w-8 text-right">{pokemon.totalQuantity}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
