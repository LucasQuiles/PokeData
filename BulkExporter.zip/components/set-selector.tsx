"use client"

import { useState } from "react"
import type { SetName } from "@/lib/card-sets"
import { cn } from "@/lib/utils"
import { ChevronDown } from "lucide-react"

interface SetSelectorProps {
  currentSet: SetName
  onSetChange: (set: SetName) => void
}

export function SetSelector({ currentSet, onSetChange }: SetSelectorProps) {
  const [isOpen, setIsOpen] = useState(false)

  const sets: SetName[] = ["Black Bolt", "White Flare"]

  return (
    <div className="flex items-center gap-3">
      <span className="text-sm font-medium">Current Set:</span>
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2 px-4 py-2 bg-background border border-border rounded-md hover:bg-accent transition-colors min-w-[200px] justify-between"
        >
          <span className="font-medium">{currentSet}</span>
          <ChevronDown className={cn("w-4 h-4 transition-transform", isOpen && "rotate-180")} />
        </button>

        {isOpen && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setIsOpen(false)} />
            <div className="absolute top-full left-0 mt-1 w-full bg-background border border-border rounded-md shadow-lg z-20 max-h-[300px] overflow-auto">
              {sets.map((set) => (
                <button
                  key={set}
                  onClick={() => {
                    onSetChange(set)
                    setIsOpen(false)
                  }}
                  className={cn(
                    "w-full px-4 py-2 text-left hover:bg-accent transition-colors",
                    currentSet === set && "bg-primary/10 font-semibold",
                  )}
                >
                  {set}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
