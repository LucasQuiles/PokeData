"use client"

import { useState } from "react"
import { Download, FileSpreadsheet } from "lucide-react"
import { useCardData } from "@/hooks/use-card-data"
import { generateCSV, downloadCSV } from "@/lib/csv-export"
import { Button } from "@/components/ui/button"
import type { SetName } from "@/lib/card-sets"

interface ExportControlsProps {
  currentSet: SetName
}

export function ExportControls({ currentSet }: ExportControlsProps) {
  const [isExporting, setIsExporting] = useState(false)
  const { getAllEntries, getEntryCount } = useCardData()

  const handleExport = async () => {
    setIsExporting(true)

    try {
      const allEntries = getAllEntries()

      // Generate CSV content
      const csvContent = generateCSV(allEntries, currentSet)

      // Download CSV file
      const timestamp = new Date().toISOString().slice(0, 10).replace(/-/g, "")
      const setPrefix = currentSet === "Black Bolt" ? "bb" : "wf"
      downloadCSV(csvContent, `${setPrefix}-export-${timestamp}.csv`)
    } catch (error) {
      console.error("Export failed:", error)
      alert("Failed to export CSV file. Please try again.")
    } finally {
      setIsExporting(false)
    }
  }

  const entryCount = getEntryCount()

  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <FileSpreadsheet className="w-4 h-4" />
        <span>
          {entryCount} {entryCount === 1 ? "entry" : "entries"}
        </span>
      </div>

      <Button onClick={handleExport} disabled={entryCount === 0 || isExporting} size="sm" className="gap-2">
        <Download className="w-4 h-4" />
        {isExporting ? "Exporting..." : "Export to CSV"}
      </Button>
    </div>
  )
}
