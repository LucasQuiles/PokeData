"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useCardData } from "@/hooks/use-card-data"
import { useKeyboardNavigation } from "@/hooks/use-keyboard-navigation"
import { getCardInfo, getSetTypes, type SetName } from "@/lib/card-sets"
import { normalizeTypeAbbreviation } from "@/lib/business-rules"
import { cn } from "@/lib/utils"

interface DataGridProps {
  currentSet: SetName
  maxCardNumber: number
}

export function DataGrid({ currentSet, maxCardNumber }: DataGridProps) {
  const [currentCardNumber, setCurrentCardNumber] = useState(1)
  const [currentTypeIndex, setCurrentTypeIndex] = useState(0)
  const [isEditing, setIsEditing] = useState(false)
  const [editValue, setEditValue] = useState("")
  const inputRef = useRef<HTMLInputElement>(null)

  const { getQuantity, setQuantity, getCardNumbers } = useCardData()
  const gridRef = useRef<HTMLDivElement>(null)

  const setTypes = getSetTypes(currentSet)
  console.log("[v0] Current set types:", setTypes)

  const typeColumnCount = setTypes.length
  const minTypeColumnWidth = 60 // minimum width in pixels
  const maxTypeColumnWidth = 120 // maximum width in pixels
  const cardColumnWidth = 240 // fixed width for card name column

  // Calculate optimal type column width
  const calculateTypeColumnWidth = () => {
    if (typeof window === "undefined") return minTypeColumnWidth
    const availableWidth = window.innerWidth - cardColumnWidth - 40 // 40px for scrollbar/padding
    const calculatedWidth = Math.floor(availableWidth / typeColumnCount)
    return Math.max(minTypeColumnWidth, Math.min(maxTypeColumnWidth, calculatedWidth))
  }

  const [typeColumnWidth, setTypeColumnWidth] = useState(calculateTypeColumnWidth())

  useEffect(() => {
    const handleResize = () => {
      setTypeColumnWidth(calculateTypeColumnWidth())
    }

    handleResize() // Initial calculation
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [typeColumnCount])

  const handleNavigate = (cardNumber: number, typeIndex: number) => {
    setCurrentCardNumber(cardNumber)
    setCurrentTypeIndex(typeIndex)
    setIsEditing(false)
  }

  const handleEnter = () => {
    setIsEditing(true)
    const currentType = setTypes[currentTypeIndex]
    const currentQty = getQuantity(currentCardNumber, currentType)
    setEditValue(currentQty > 0 ? String(currentQty) : "")
  }

  const handleDelete = () => {
    const currentType = setTypes[currentTypeIndex]
    setQuantity(currentCardNumber, currentType, 0)
  }

  const handleTyping = (key: string) => {
    if (!isEditing && /^[0-9a-zA-Z]$/.test(key)) {
      setIsEditing(true)
      setEditValue(key)
    }
  }

  const handleCellClick = (cardNumber: number, typeIndex: number) => {
    setCurrentCardNumber(cardNumber)
    setCurrentTypeIndex(typeIndex)
    setIsEditing(false)
  }

  useKeyboardNavigation({
    currentCardNumber,
    currentTypeIndex,
    onNavigate: handleNavigate,
    onEnter: handleEnter,
    onDelete: handleDelete,
    onTyping: handleTyping,
    minCardNumber: 1,
    maxCardNumber,
    isEditing,
    maxTypeIndex: setTypes.length - 1,
  })

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus()
      inputRef.current.select()
    }
  }, [isEditing])

  const handleSaveEdit = () => {
    if (!editValue.trim()) {
      // Empty input = clear the cell
      const currentType = setTypes[currentTypeIndex]
      setQuantity(currentCardNumber, currentType, 0)
      setIsEditing(false)
      return
    }

    // Parse input: could be just a number or include type abbreviation
    const match = editValue.match(/^(\d+)([a-zA-Z\s]*)$/)
    if (!match) {
      setIsEditing(false)
      return
    }

    const quantity = Number.parseInt(match[1], 10)
    const typeAbbr = match[2].trim()

    if (isNaN(quantity) || quantity < 0) {
      setIsEditing(false)
      return
    }

    let targetType = setTypes[currentTypeIndex]

    // If type abbreviation provided, normalize it
    if (typeAbbr) {
      const normalized = normalizeTypeAbbreviation(typeAbbr)
      if (normalized) {
        targetType = normalized
      }
    }

    setQuantity(currentCardNumber, targetType, quantity)

    // Move to the target type column if it changed
    if (targetType !== setTypes[currentTypeIndex]) {
      const newTypeIndex = setTypes.indexOf(targetType)
      if (newTypeIndex !== -1) {
        setCurrentTypeIndex(newTypeIndex)
      }
    }

    setIsEditing(false)
  }

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault()
      handleSaveEdit()
    } else if (e.key === "Escape") {
      e.preventDefault()
      setIsEditing(false)
    } else if (e.key === "Tab") {
      e.preventDefault()
      handleSaveEdit()
      // Move to next cell
      const newTypeIndex = currentTypeIndex + 1
      if (newTypeIndex < setTypes.length) {
        setCurrentTypeIndex(newTypeIndex)
      } else {
        setCurrentTypeIndex(0)
        setCurrentCardNumber(Math.min(maxCardNumber, currentCardNumber + 1))
      }
    } else if (e.key === "ArrowUp" || e.key === "ArrowDown" || e.key === "ArrowLeft" || e.key === "ArrowRight") {
      // Save current value and navigate
      e.preventDefault()
      handleSaveEdit()

      // Calculate new position
      let newCardNumber = currentCardNumber
      let newTypeIndex = currentTypeIndex

      switch (e.key) {
        case "ArrowUp":
          newCardNumber = Math.max(1, currentCardNumber - 1)
          break
        case "ArrowDown":
          newCardNumber = Math.min(maxCardNumber, currentCardNumber + 1)
          break
        case "ArrowLeft":
          newTypeIndex = Math.max(0, currentTypeIndex - 1)
          break
        case "ArrowRight":
          newTypeIndex = Math.min(setTypes.length - 1, currentTypeIndex + 1)
          break
      }

      // Navigate to new position
      setCurrentCardNumber(newCardNumber)
      setCurrentTypeIndex(newTypeIndex)
    }
  }

  const cardNumbers = getCardNumbers()
  const visibleCardNumbers = Array.from(new Set([currentCardNumber, ...cardNumbers])).sort((a, b) => a - b)

  const displayCardNumbers = [...visibleCardNumbers]
  while (displayCardNumbers.length < 10) {
    const nextNumber = displayCardNumbers.length > 0 ? Math.max(...displayCardNumbers) + 1 : currentCardNumber
    if (nextNumber <= maxCardNumber) {
      displayCardNumbers.push(nextNumber)
    } else {
      break
    }
  }
  displayCardNumbers.sort((a, b) => a - b)

  const currentType = setTypes[currentTypeIndex]

  const getCardName = (cardNumber: number): string => {
    const cardInfo = getCardInfo(currentSet, cardNumber)
    return cardInfo?.name || "Unknown Card"
  }

  return (
    <div className="flex flex-col h-full" ref={gridRef}>
      <div
        className="grid border-b border-border bg-muted/30 sticky top-0 z-10"
        style={{
          gridTemplateColumns: `${cardColumnWidth}px repeat(${typeColumnCount}, ${typeColumnWidth}px)`,
        }}
      >
        <div className="px-3 py-1.5 font-semibold text-xs border-r border-border">Card</div>
        {setTypes.map((type, index) => (
          <div
            key={type}
            className={cn(
              "px-1.5 py-1.5 text-[10px] font-medium text-center border-r border-border truncate",
              index === currentTypeIndex && "bg-primary/10",
            )}
          >
            {type}
          </div>
        ))}
      </div>

      <div className="flex-1 overflow-auto">
        {displayCardNumbers.map((cardNumber) => (
          <div
            key={cardNumber}
            className={cn(
              "grid border-b border-border hover:bg-accent/30 transition-colors",
              cardNumber === currentCardNumber && "bg-accent/50",
            )}
            style={{
              gridTemplateColumns: `${cardColumnWidth}px repeat(${typeColumnCount}, ${typeColumnWidth}px)`,
            }}
          >
            <div className="px-3 py-1.5 border-r border-border">
              <div className="font-mono text-xs font-semibold">{String(cardNumber).padStart(3, "0")}</div>
              <div className="text-[11px] text-muted-foreground truncate">{getCardName(cardNumber)}</div>
            </div>
            {setTypes.map((type, typeIndex) => {
              const quantity = getQuantity(cardNumber, type)
              const isSelected = cardNumber === currentCardNumber && typeIndex === currentTypeIndex
              const isEditingThisCell = isSelected && isEditing

              return (
                <div
                  key={type}
                  onClick={() => handleCellClick(cardNumber, typeIndex)}
                  className={cn(
                    "px-1.5 py-1.5 text-xs text-center border-r border-border flex items-center justify-center cursor-pointer",
                    isSelected && "bg-primary text-primary-foreground font-bold ring-2 ring-primary ring-inset",
                    quantity > 0 && !isSelected && "font-semibold text-foreground",
                  )}
                >
                  {isEditingThisCell ? (
                    <input
                      ref={inputRef}
                      type="text"
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      onKeyDown={handleInputKeyDown}
                      onBlur={handleSaveEdit}
                      className="w-full h-full bg-transparent text-center outline-none"
                      maxLength={10}
                    />
                  ) : (
                    <>{quantity > 0 ? quantity : ""}</>
                  )}
                </div>
              )
            })}
          </div>
        ))}
      </div>

      <div className="border-t border-border bg-muted/30 px-3 py-1.5 flex items-center justify-between text-xs">
        <div className="font-mono">
          {String(currentCardNumber).padStart(3, "0")} {getCardName(currentCardNumber)} • {currentType}
        </div>
        <div className="text-muted-foreground">
          {isEditing
            ? "Arrows: Save & Navigate • Enter: Save • Esc: Cancel • Tab: Next"
            : "Click/Type/Enter: Edit • Delete: Clear • Arrows: Navigate"}
        </div>
      </div>
    </div>
  )
}
