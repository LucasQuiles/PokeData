"use client"
import { cn } from "@/lib/utils"

export type SheetType = "black-bolt" | "white-flare"

interface SheetSelectorProps {
  value: SheetType
  onChange: (value: SheetType) => void
}

export function SheetSelector({ value, onChange }: SheetSelectorProps) {
  return (
    <div className="flex items-center gap-2 bg-muted/50 rounded-lg p-1">
      <button
        onClick={() => onChange("black-bolt")}
        className={cn(
          "px-4 py-2 text-sm font-medium rounded-md transition-colors",
          value === "black-bolt"
            ? "bg-background text-foreground shadow-sm"
            : "text-muted-foreground hover:text-foreground",
        )}
      >
        Black Bolt
      </button>
      <button
        onClick={() => onChange("white-flare")}
        className={cn(
          "px-4 py-2 text-sm font-medium rounded-md transition-colors",
          value === "white-flare"
            ? "bg-background text-foreground shadow-sm"
            : "text-muted-foreground hover:text-foreground",
        )}
      >
        White Flare
      </button>
    </div>
  )
}
