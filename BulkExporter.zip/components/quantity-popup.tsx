"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { TYPE_ABBREVIATIONS, type CardType } from "@/lib/types"
import { cn } from "@/lib/utils"

interface QuantityPopupProps {
  cardNumber: number
  currentType: CardType
  currentQuantity: number
  onSave: (quantity: number, type?: CardType) => void
  onCancel: () => void
}

export function QuantityPopup({ cardNumber, currentType, currentQuantity, onSave, onCancel }: QuantityPopupProps) {
  const [input, setInput] = useState("")
  const [parsedQuantity, setParsedQuantity] = useState<number | null>(null)
  const [parsedType, setParsedType] = useState<CardType | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  useEffect(() => {
    const trimmed = input.trim().toUpperCase()

    if (trimmed === "") {
      setParsedQuantity(0)
      setParsedType(null)
      return
    }

    // Try to parse as just a number
    const numMatch = trimmed.match(/^(\d+)$/)
    if (numMatch) {
      const qty = Number.parseInt(numMatch[1], 10)
      setParsedQuantity(qty)
      setParsedType(null)
      return
    }

    // Try to parse as number + type abbreviation (e.g., "4RH", "2 FA")
    const typeMatch = trimmed.match(/^(\d+)\s*([A-Z]+)$/)
    if (typeMatch) {
      const qty = Number.parseInt(typeMatch[1], 10)
      const abbrev = typeMatch[2]
      const type = TYPE_ABBREVIATIONS[abbrev]

      if (type) {
        setParsedQuantity(qty)
        setParsedType(type)
      } else {
        setParsedQuantity(null)
        setParsedType(null)
      }
      return
    }

    setParsedQuantity(null)
    setParsedType(null)
  }, [input])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      if (parsedQuantity !== null && parsedQuantity >= 0) {
        console.log("[v0] Popup saving:", { parsedQuantity, parsedType })
        onSave(parsedQuantity, parsedType || undefined)
      }
    } else if (e.key === "Escape") {
      e.preventDefault()
      onCancel()
    }
  }

  const isValid = parsedQuantity !== null && parsedQuantity >= 0 && parsedQuantity <= 999

  const effectiveType = parsedType || currentType

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onCancel}>
      <div className="bg-card border border-border rounded-lg shadow-xl w-96" onClick={(e) => e.stopPropagation()}>
        <div className="border-b border-border px-6 py-4">
          <h2 className="text-lg font-semibold">Enter Quantity</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Card {String(cardNumber).padStart(3, "0")} - {effectiveType}
          </p>
        </div>

        <div className="px-6 py-6">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Enter quantity or leave empty to clear"
            className={cn(
              "w-full px-4 py-3 text-lg font-mono border rounded-md",
              "focus:outline-none focus:ring-2 focus:ring-primary",
              isValid ? "border-border" : input ? "border-destructive" : "border-border",
            )}
          />

          {currentQuantity > 0 && <p className="text-sm text-muted-foreground mt-2">Current: {currentQuantity}</p>}

          {parsedQuantity === 0 && <p className="text-sm text-primary mt-2">Will clear this entry</p>}

          {input && !isValid && (
            <p className="text-sm text-destructive mt-2">
              Invalid input. Enter a number (0-999) or number + type (e.g., 4RH)
            </p>
          )}

          {parsedType && parsedType !== currentType && (
            <p className="text-sm text-primary mt-2">Type will change to: {parsedType}</p>
          )}

          <div className="mt-4 text-xs text-muted-foreground space-y-1">
            <p>
              <strong>Quick entry:</strong> Type quantity and press Enter
            </p>
            <p>
              <strong>Clear value:</strong> Leave empty or type 0
            </p>
            <p>
              <strong>Type shortcuts:</strong> N, RH, H, FA, RR, etc.
            </p>
          </div>
        </div>

        <div className="border-t border-border px-6 py-4 flex items-center justify-between">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Cancel (Esc)
          </button>
          <button
            onClick={() => isValid && parsedQuantity !== null && onSave(parsedQuantity, parsedType || undefined)}
            disabled={!isValid}
            className={cn(
              "px-6 py-2 text-sm font-medium rounded-md transition-colors",
              isValid
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "bg-muted text-muted-foreground cursor-not-allowed",
            )}
          >
            Save (Enter)
          </button>
        </div>
      </div>
    </div>
  )
}
