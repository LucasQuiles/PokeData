"use client"

import { useEffect, useCallback } from "react"

interface UseKeyboardNavigationProps {
  currentCardNumber: number
  currentTypeIndex: number
  onNavigate: (cardNumber: number, typeIndex: number) => void
  onEnter: () => void
  onDelete?: () => void
  onTyping?: (key: string) => void
  minCardNumber?: number
  maxCardNumber?: number
  isEditing?: boolean
  maxTypeIndex?: number
}

export function useKeyboardNavigation({
  currentCardNumber,
  currentTypeIndex,
  onNavigate,
  onEnter,
  onDelete,
  onTyping,
  minCardNumber = 1,
  maxCardNumber = 999,
  isEditing = false,
  maxTypeIndex = 15,
}: UseKeyboardNavigationProps) {
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return
      }

      if (isEditing) {
        return
      }

      let newCardNumber = currentCardNumber
      let newTypeIndex = currentTypeIndex

      switch (e.key) {
        case "ArrowUp":
          e.preventDefault()
          newCardNumber = Math.max(minCardNumber, currentCardNumber - 1)
          break
        case "ArrowDown":
          e.preventDefault()
          newCardNumber = Math.min(maxCardNumber, currentCardNumber + 1)
          break
        case "ArrowLeft":
          e.preventDefault()
          newTypeIndex = Math.max(0, currentTypeIndex - 1)
          break
        case "ArrowRight":
          e.preventDefault()
          newTypeIndex = Math.min(maxTypeIndex, currentTypeIndex + 1)
          break
        case "Enter":
          e.preventDefault()
          onEnter()
          return
        case "Delete":
        case "Backspace":
          e.preventDefault()
          if (onDelete) {
            onDelete()
          }
          return
        default:
          if (onTyping && /^[0-9a-zA-Z]$/.test(e.key)) {
            e.preventDefault()
            onTyping(e.key)
          }
          return
      }

      if (newCardNumber !== currentCardNumber || newTypeIndex !== currentTypeIndex) {
        onNavigate(newCardNumber, newTypeIndex)
      }
    },
    [
      currentCardNumber,
      currentTypeIndex,
      onNavigate,
      onEnter,
      onDelete,
      onTyping,
      minCardNumber,
      maxCardNumber,
      isEditing,
      maxTypeIndex,
    ],
  )

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [handleKeyDown])
}
