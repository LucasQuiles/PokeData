"use client"

import { useState, useCallback, useEffect } from "react"
import { CardDataStore } from "@/lib/card-data-store"
import type { CardType } from "@/lib/types"
import type { SetName } from "@/lib/card-sets"

const store = new CardDataStore()

export function useCardData() {
  const [, setUpdateTrigger] = useState(0)

  useEffect(() => {
    const unsubscribe = store.subscribe(() => {
      setUpdateTrigger((prev) => prev + 1)
    })
    return unsubscribe
  }, [])

  const forceUpdate = useCallback(() => {
    setUpdateTrigger((prev) => prev + 1)
  }, [])

  const setCurrentSet = useCallback(
    (setName: SetName) => {
      store.setCurrentSet(setName)
      forceUpdate()
    },
    [forceUpdate],
  )

  const setQuantity = useCallback(
    (cardNumber: number, type: CardType, quantity: number) => {
      store.setQuantity(cardNumber, type, quantity)
      forceUpdate()
    },
    [forceUpdate],
  )

  const getQuantity = useCallback((cardNumber: number, type: CardType) => {
    return store.getQuantity(cardNumber, type)
  }, [])

  const getCardEntries = useCallback((cardNumber: number) => {
    return store.getCardEntries(cardNumber)
  }, [])

  const getAllEntries = useCallback(() => {
    return store.getAllEntries()
  }, [])

  const getCardNumbers = useCallback(() => {
    return store.getCardNumbers()
  }, [])

  const clearAll = useCallback(() => {
    store.clear()
    forceUpdate()
  }, [forceUpdate])

  const getEntryCount = useCallback(() => {
    return store.getEntryCount()
  }, [])

  return {
    setCurrentSet,
    setQuantity,
    getQuantity,
    getCardEntries,
    getAllEntries,
    getCardNumbers,
    clearAll,
    getEntryCount,
  }
}
