import requests
import csv
import json
from io import StringIO

# Fetch and parse Black Bolt CSV
bb_url = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bb-17drsWS6wDYhcKyXsQvVgSReCdXHUK.csv"
bb_response = requests.get(bb_url)
bb_csv = csv.DictReader(StringIO(bb_response.text))

bb_cards = []
for row in bb_csv:
    # Extract card number from Num field (e.g., "183/086" -> 183)
    num_str = row.get("Num", "")
    if "/" in num_str:
        card_num = int(num_str.split("/")[0])
    else:
        card_num = int(num_str) if num_str.isdigit() else 0
    
    bb_cards.append({
        "number": card_num,
        "name": row.get("Pokemon", "").strip(),
        "type": row.get("Type", "").strip(),
    })

# Fetch and parse White Flare CSV
wf_url = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/wf-ol3phvva0aHgtZLMeQMBdBEqe4hOOV.csv"
wf_response = requests.get(wf_url)
wf_csv = csv.DictReader(StringIO(wf_response.text))

wf_cards = []
for row in wf_csv:
    # Extract card number from Num field
    num_str = row.get("Num", "")
    card_num = int(num_str) if num_str.isdigit() else 0
    
    wf_cards.append({
        "number": card_num,
        "name": row.get("Card", "").strip(),
        "type": row.get("Type", "").strip(),
    })

# Output as JSON
output = {
    "blackBolt": bb_cards,
    "whiteFlare": wf_cards
}

print(json.dumps(output, indent=2))
