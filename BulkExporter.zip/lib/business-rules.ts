// Business rules for card type management, especially Holo rules

import type { CardType, CardEntry } from "./types"

// Special rarities that disallow Holo in the same card group
const HOLO_DISALLOWING_TYPES: CardType[] = [
  "Promo",
  "Cosmos Holo",
  "Radiant",
  "Amazing Rare",
  "Trainer Gallery",
  "Full Art",
  "Rainbow Rare",
  "Gold",
  "Hyper Rare",
  "Special Illustration Rare",
  "Illustration Rare",
  "Ultra Rare",
  "Secret Rare",
]

export interface BusinessRuleResult {
  shouldAddHolo: boolean
  shouldRemoveHolo: boolean
  reason?: string
}

/**
 * Determines if Holo should be auto-added or auto-removed based on card entries
 *
 * Rules:
 * 1. If any special rarity exists, Holo is disallowed (should be removed)
 * 2. If only Normal and/or Reverse Holo exist, exactly one Holo should be added
 * 3. If Holo already exists and conditions are met, keep it
 */
export function evaluateHoloRules(entries: CardEntry[]): BusinessRuleResult {
  const types = new Set(entries.map((e) => e.type))

  // Check if any disallowing types exist
  const hasDisallowingType = HOLO_DISALLOWING_TYPES.some((type) => types.has(type))

  if (hasDisallowingType) {
    // If special rarities exist, Holo should be removed
    if (types.has("Holo")) {
      return {
        shouldAddHolo: false,
        shouldRemoveHolo: true,
        reason: "Holo removed: special rarity present",
      }
    }
    return {
      shouldAddHolo: false,
      shouldRemoveHolo: false,
    }
  }

  // Only Normal and/or Reverse Holo exist (or empty)
  const hasOnlyBasicTypes = Array.from(types).every((type) => type === "Normal" || type === "Reverse Holo")

  if (hasOnlyBasicTypes && types.size > 0) {
    // Should have exactly one Holo
    if (!types.has("Holo")) {
      return {
        shouldAddHolo: true,
        shouldRemoveHolo: false,
        reason: "Holo added: only basic types present",
      }
    }
  }

  return {
    shouldAddHolo: false,
    shouldRemoveHolo: false,
  }
}

/**
 * Validates card number is within acceptable range
 */
export function validateCardNumber(cardNumber: number, min = 1, max = 999): boolean {
  return Number.isInteger(cardNumber) && cardNumber >= min && cardNumber <= max
}

/**
 * Validates quantity is within acceptable range
 */
export function validateQuantity(quantity: number): boolean {
  return Number.isInteger(quantity) && quantity >= 0 && quantity <= 999
}

/**
 * Formats card number with leading zeros
 */
export function formatCardNumber(cardNumber: number): string {
  return String(cardNumber).padStart(3, "0")
}

/**
 * Normalizes type abbreviations to full type names
 */
export function normalizeTypeAbbreviation(abbr: string): CardType | null {
  const normalized = abbr.toLowerCase().trim()

  const abbreviationMap: Record<string, CardType> = {
    n: "Normal",
    normal: "Normal",
    rh: "Reverse Holo",
    reverse: "Reverse Holo",
    "reverse holo": "Reverse Holo",
    h: "Holo",
    holo: "Holo",
    p: "Promo",
    promo: "Promo",
    ch: "Cosmos Holo",
    cosmos: "Cosmos Holo",
    "cosmos holo": "Cosmos Holo",
    r: "Radiant",
    radiant: "Radiant",
    ar: "Amazing Rare",
    amazing: "Amazing Rare",
    "amazing rare": "Amazing Rare",
    tg: "Trainer Gallery",
    trainer: "Trainer Gallery",
    "trainer gallery": "Trainer Gallery",
    fa: "Full Art",
    "full art": "Full Art",
    rr: "Rainbow Rare",
    rainbow: "Rainbow Rare",
    "rainbow rare": "Rainbow Rare",
    g: "Gold",
    gold: "Gold",
    hr: "Hyper Rare",
    hyper: "Hyper Rare",
    "hyper rare": "Hyper Rare",
    sir: "Special Illustration Rare",
    "special illustration": "Special Illustration Rare",
    "special illustration rare": "Special Illustration Rare",
    ir: "Illustration Rare",
    illustration: "Illustration Rare",
    "illustration rare": "Illustration Rare",
    ur: "Ultra Rare",
    ultra: "Ultra Rare",
    "ultra rare": "Ultra Rare",
    sr: "Secret Rare",
    secret: "Secret Rare",
    "secret rare": "Secret Rare",
  }

  return abbreviationMap[normalized] || null
}
