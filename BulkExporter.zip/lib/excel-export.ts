// Excel export functionality using xlsx library

import type { CardEntry, SheetTemplate, CardType } from "./types"
import { formatCardNumber } from "./business-rules"

// Type for row data in Excel format
type ExcelRow = Record<string, string | number>

/**
 * Converts card entries to Excel rows for a specific template
 */
export function convertToExcelRows(entries: CardEntry[], template: SheetTemplate): ExcelRow[] {
  // Group entries by card number
  const cardGroups = new Map<number, Map<CardType, number>>()

  for (const entry of entries) {
    if (!cardGroups.has(entry.cardNumber)) {
      cardGroups.set(entry.cardNumber, new Map())
    }
    cardGroups.get(entry.cardNumber)!.set(entry.type, entry.quantity)
  }

  // Convert to rows
  const rows: ExcelRow[] = []

  for (const [cardNumber, typeMap] of Array.from(cardGroups.entries()).sort((a, b) => a[0] - b[0])) {
    const row: ExcelRow = {
      "Card Number": formatCardNumber(cardNumber),
    }

    // Add columns for each type in template order
    for (const column of template.columns) {
      if (column === "Card Number") continue

      const type = column as CardType
      const quantity = typeMap.get(type) || ""
      row[column] = quantity
    }

    rows.push(row)
  }

  return rows
}

/**
 * Generates Excel file data from card entries
 * Returns a Blob that can be downloaded
 */
export async function generateExcelFile(
  blackBoltEntries: CardEntry[],
  whiteFareEntries: CardEntry[],
  blackBoltTemplate: SheetTemplate,
  whiteFlareTemplate: SheetTemplate,
): Promise<Blob> {
  // Dynamically import xlsx to avoid bundling it unnecessarily
  const XLSX = await import("xlsx")

  // Create workbook
  const workbook = XLSX.utils.book_new()

  // Add Black Bolt sheet
  const blackBoltRows = convertToExcelRows(blackBoltEntries, blackBoltTemplate)
  const blackBoltSheet = XLSX.utils.json_to_sheet(blackBoltRows, {
    header: blackBoltTemplate.columns,
  })
  XLSX.utils.book_append_sheet(workbook, blackBoltSheet, blackBoltTemplate.name)

  // Add White Flare sheet
  const whiteFlareRows = convertToExcelRows(whiteFareEntries, whiteFlareTemplate)
  const whiteFlareSheet = XLSX.utils.json_to_sheet(whiteFlareRows, {
    header: whiteFlareTemplate.columns,
  })
  XLSX.utils.book_append_sheet(workbook, whiteFlareSheet, whiteFlareTemplate.name)

  // Generate Excel file
  const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" })
  const blob = new Blob([excelBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  })

  return blob
}

/**
 * Triggers download of Excel file
 */
export function downloadExcelFile(blob: Blob, filename = "bbwf-export.xlsx"): void {
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}
