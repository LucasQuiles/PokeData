// Client-side data store for card entries using SWR for state management
import { type CardEntry, type CardType, CANONICAL_TYPE_ORDER } from "./types"
import { evaluateHoloRules } from "./business-rules"
import type { SetName } from "./card-sets"

export class CardDataStore {
  private data: Map<string, CardEntry> = new Map()
  private currentSet: SetName = "Black Bolt"
  private storageKey = "bbwf-card-data"
  private applyHoloRulesEnabled = false
  private subscribers: Set<() => void> = new Set()

  constructor() {
    this.loadFromStorage()
  }

  setCurrentSet(setName: SetName): void {
    this.saveToStorage() // Save current set data first
    this.currentSet = setName
    this.loadFromStorage() // Load new set data
    this.notify()
  }

  getCurrentSet(): SetName {
    return this.currentSet
  }

  private loadFromStorage(): void {
    if (typeof window === "undefined") return

    try {
      const stored = localStorage.getItem(this.storageKey)
      if (!stored) return

      const allData = JSON.parse(stored)
      const setData = allData[this.currentSet] || []

      this.data.clear()
      for (const entry of setData) {
        const key = this.getKey(entry.cardNumber, entry.type)
        this.data.set(key, entry)
      }
    } catch (error) {
      console.error("[v0] Failed to load from localStorage:", error)
    }
  }

  private saveToStorage(): void {
    if (typeof window === "undefined") return

    try {
      const stored = localStorage.getItem(this.storageKey)
      const allData = stored ? JSON.parse(stored) : {}

      allData[this.currentSet] = Array.from(this.data.values())

      localStorage.setItem(this.storageKey, JSON.stringify(allData))
    } catch (error) {
      console.error("[v0] Failed to save to localStorage:", error)
    }
  }

  private getKey(cardNumber: number, type: CardType): string {
    return `${cardNumber}-${type}`
  }

  setQuantity(cardNumber: number, type: CardType, quantity: number): void {
    console.log("[v0] setQuantity called:", { cardNumber, type, quantity })
    const key = this.getKey(cardNumber, type)

    if (quantity <= 0) {
      console.log("[v0] Deleting entry:", key)
      this.data.delete(key)
    } else {
      console.log("[v0] Setting entry:", key, quantity)
      this.data.set(key, { cardNumber, type, quantity })
    }

    if (this.applyHoloRulesEnabled) {
      this.applyHoloRules(cardNumber)
    }

    this.saveToStorage()
    console.log("[v0] Current data size:", this.data.size)
    this.notify()
  }

  // Get quantity for a card
  getQuantity(cardNumber: number, type: CardType): number {
    const key = this.getKey(cardNumber, type)
    return this.data.get(key)?.quantity || 0
  }

  // Get all entries for a card number
  getCardEntries(cardNumber: number): CardEntry[] {
    const entries: CardEntry[] = []
    for (const type of CANONICAL_TYPE_ORDER) {
      const quantity = this.getQuantity(cardNumber, type)
      if (quantity > 0) {
        entries.push({ cardNumber, type, quantity })
      }
    }
    return entries
  }

  // Get all entries sorted by card number
  getAllEntries(): CardEntry[] {
    const entries = Array.from(this.data.values())
    return entries.sort((a, b) => {
      if (a.cardNumber !== b.cardNumber) {
        return a.cardNumber - b.cardNumber
      }
      return CANONICAL_TYPE_ORDER.indexOf(a.type) - CANONICAL_TYPE_ORDER.indexOf(b.type)
    })
  }

  // Get all unique card numbers
  getCardNumbers(): number[] {
    const numbers = new Set<number>()
    for (const entry of this.data.values()) {
      numbers.add(entry.cardNumber)
    }
    return Array.from(numbers).sort((a, b) => a - b)
  }

  // Clear all data
  clear(): void {
    this.data.clear()
    this.saveToStorage() // Persist after clearing
    this.notify()
  }

  // Get total entry count
  getEntryCount(): number {
    return this.data.size
  }

  private applyHoloRules(cardNumber: number): void {
    const entries = this.getCardEntries(cardNumber)
    const rules = evaluateHoloRules(entries)

    if (rules.shouldAddHolo) {
      const holoKey = this.getKey(cardNumber, "Holo")
      if (!this.data.has(holoKey)) {
        this.data.set(holoKey, { cardNumber, type: "Holo", quantity: 1 })
      }
    } else if (rules.shouldRemoveHolo) {
      const holoKey = this.getKey(cardNumber, "Holo")
      this.data.delete(holoKey)
    }
  }

  setHoloRulesEnabled(enabled: boolean): void {
    this.applyHoloRulesEnabled = enabled
  }

  getHoloRulesEnabled(): boolean {
    return this.applyHoloRulesEnabled
  }

  subscribe(callback: () => void): () => void {
    this.subscribers.add(callback)
    return () => {
      this.subscribers.delete(callback)
    }
  }

  private notify(): void {
    this.subscribers.forEach((callback) => callback())
  }
}
