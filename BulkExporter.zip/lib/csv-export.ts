// Simple CSV export functionality

import type { CardEntry } from "./types"
import { formatCardNumber } from "./business-rules"
import { getCardInfo, type SetName } from "./card-sets"

/**
 * Converts card entries to CSV format: POKEMON,NUMBER,RARITY,QTY
 */
export function generateCSV(entries: CardEntry[], setName: SetName): string {
  // Header row
  const rows = ["POKEMON,NUMBER,RARITY,QTY"]

  // Sort entries by card number, then by type
  const sortedEntries = [...entries].sort((a, b) => {
    if (a.cardNumber !== b.cardNumber) {
      return a.cardNumber - b.cardNumber
    }
    return a.type.localeCompare(b.type)
  })

  // Add data rows
  for (const entry of sortedEntries) {
    const cardInfo = getCardInfo(setName, entry.cardNumber)
    const pokemon = cardInfo?.name || "Unknown"
    const number = formatCardNumber(entry.cardNumber)
    const rarity = entry.type
    const qty = entry.quantity

    rows.push(`${pokemon},${number},${rarity},${qty}`)
  }

  return rows.join("\n")
}

/**
 * Triggers download of CSV file
 */
export function downloadCSV(csvContent: string, filename = "export.csv"): void {
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}
