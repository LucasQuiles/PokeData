// Core data types for the BBWF Template Exporter

export type CardType =
  | "Normal"
  | "Reverse Holo"
  | "Holo"
  | "Promo"
  | "Cosmos Holo"
  | "Radiant"
  | "Amazing Rare"
  | "Trainer Gallery"
  | "Full Art"
  | "Rainbow Rare"
  | "Gold"
  | "Hyper Rare"
  | "Special Illustration Rare"
  | "Illustration Rare"
  | "Ultra Rare"
  | "Secret Rare"

export const CANONICAL_TYPE_ORDER: CardType[] = [
  "Normal",
  "Reverse Holo",
  "Holo",
  "Promo",
  "Cosmos Holo",
  "Radiant",
  "Amazing Rare",
  "Trainer Gallery",
  "Full Art",
  "Rainbow Rare",
  "Gold",
  "Hyper Rare",
  "Special Illustration Rare",
  "Illustration Rare",
  "Ultra Rare",
  "Secret Rare",
]

export const TYPE_ABBREVIATIONS: Record<string, CardType> = {
  N: "Normal",
  RH: "Reverse Holo",
  H: "Holo",
  P: "Promo",
  CH: "Cosmos Holo",
  R: "Radiant",
  AR: "Amazing Rare",
  TG: "Trainer Gallery",
  FA: "Full Art",
  RR: "Rainbow Rare",
  G: "Gold",
  HR: "Hyper Rare",
  SIR: "Special Illustration Rare",
  IR: "Illustration Rare",
  UR: "Ultra Rare",
  SR: "Secret Rare",
}

export interface CardEntry {
  cardNumber: number
  type: CardType
  quantity: number
}

export interface SheetTemplate {
  name: string
  columns: string[]
}

export const BLACK_BOLT_TEMPLATE: SheetTemplate = {
  name: "Black Bolt",
  columns: [
    "Card Number",
    "Normal",
    "Reverse Holo",
    "Holo",
    "Promo",
    "Cosmos Holo",
    "Radiant",
    "Amazing Rare",
    "Trainer Gallery",
    "Full Art",
    "Rainbow Rare",
    "Gold",
    "Hyper Rare",
    "Special Illustration Rare",
    "Illustration Rare",
    "Ultra Rare",
    "Secret Rare",
  ],
}

export const WHITE_FLARE_TEMPLATE: SheetTemplate = {
  name: "White Flare",
  columns: [
    "Card Number",
    "Normal",
    "Reverse Holo",
    "Holo",
    "Promo",
    "Cosmos Holo",
    "Radiant",
    "Amazing Rare",
    "Trainer Gallery",
    "Full Art",
    "Rainbow Rare",
    "Gold",
    "Hyper Rare",
    "Special Illustration Rare",
    "Illustration Rare",
    "Ultra Rare",
    "Secret Rare",
  ],
}
