// Card set data structures and loaders

export interface CardInfo {
  number: number
  name: string
  type: string
}

export type SetName = "Black Bolt" | "White Flare"

export interface CardSet {
  name: SetName
  cards: CardInfo[]
  uniqueTypes: string[]
}

// Cache for loaded card data
let cardDataCache: {
  blackBolt: CardInfo[]
  whiteFlare: CardInfo[]
  blackBoltTypes: string[]
  whiteFlareTypes: string[]
} | null = null

export async function loadCardData(): Promise<{
  blackBolt: CardInfo[]
  whiteFlare: CardInfo[]
  blackBoltTypes: string[]
  whiteFlareTypes: string[]
}> {
  if (cardDataCache) {
    return cardDataCache
  }

  try {
    // Fetch Black Bolt CSV
    const bbResponse = await fetch(
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bb-17drsWS6wDYhcKyXsQvVgSReCdXHUK.csv",
    )
    const bbText = await bbResponse.text()
    const bbCards = parseCSV(bbText, "Pokemon")
    const blackBoltTypes = extractUniqueTypes(bbCards)

    // Fetch White Flare CSV
    const wfResponse = await fetch(
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/wf-ol3phvva0aHgtZLMeQMBdBEqe4hOOV.csv",
    )
    const wfText = await wfResponse.text()
    const wfCards = parseCSV(wfText, "Card")
    const whiteFlareTypes = extractUniqueTypes(wfCards)

    cardDataCache = {
      blackBolt: bbCards,
      whiteFlare: wfCards,
      blackBoltTypes,
      whiteFlareTypes,
    }

    console.log("[v0] Loaded card data - BB types:", blackBoltTypes, "WF types:", whiteFlareTypes)

    return cardDataCache
  } catch (error) {
    console.error("[v0] Failed to load card data:", error)
    return { blackBolt: [], whiteFlare: [], blackBoltTypes: [], whiteFlareTypes: [] }
  }
}

function parseCSV(csvText: string, nameColumn: string): CardInfo[] {
  const lines = csvText.trim().split("\n")
  if (lines.length === 0) return []

  const headers = lines[0].split(",").map((h) => h.trim())
  const nameIndex = headers.indexOf(nameColumn)
  const numIndex = headers.indexOf("Num")
  const typeIndex = headers.indexOf("Type")

  if (nameIndex === -1 || numIndex === -1) {
    console.error("[v0] CSV missing required columns")
    return []
  }

  const cards: CardInfo[] = []

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i]
    if (!line.trim()) continue

    const values = line.split(",").map((v) => v.trim())

    const numStr = values[numIndex] || ""
    let cardNum = 0

    // Handle formats like "183/086" or "000"
    if (numStr.includes("/")) {
      cardNum = Number.parseInt(numStr.split("/")[0], 10)
    } else {
      cardNum = Number.parseInt(numStr, 10)
    }

    if (isNaN(cardNum) || cardNum === 0) continue

    cards.push({
      number: cardNum,
      name: values[nameIndex] || "",
      type: typeIndex !== -1 ? values[typeIndex] || "" : "",
    })
  }

  return cards
}

export function getCardInfo(setName: SetName, cardNumber: number): CardInfo | null {
  if (!cardDataCache) return null

  const cards = setName === "Black Bolt" ? cardDataCache.blackBolt : cardDataCache.whiteFlare
  return cards.find((c) => c.number === cardNumber) || null
}

export function getMaxCardNumber(setName: SetName): number {
  if (!cardDataCache) return 999

  const cards = setName === "Black Bolt" ? cardDataCache.blackBolt : cardDataCache.whiteFlare
  return Math.max(...cards.map((c) => c.number), 1)
}

function extractUniqueTypes(cards: CardInfo[]): string[] {
  const typeSet = new Set<string>()

  for (const card of cards) {
    if (card.type && card.type.trim()) {
      typeSet.add(card.type.trim())
    }
  }

  const types = Array.from(typeSet)
  console.log("[v0] Extracted unique types:", types)
  return types
}

export function getSetTypes(setName: SetName): string[] {
  if (!cardDataCache) return []

  return setName === "Black Bolt" ? cardDataCache.blackBoltTypes : cardDataCache.whiteFlareTypes
}
